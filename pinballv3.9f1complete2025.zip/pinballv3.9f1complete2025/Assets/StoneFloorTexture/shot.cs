using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shot : MonoBehaviour
{
    public float min_power = 500;
    public float max_power = 5000;
    bool hasshot = false;
    Rigidbody rb;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && !hasshot)
        {
            rb.AddForce(transform.forward * Random.Range(min_power, max_power),ForceMode.Impulse);
            hasshot = true;
        }
    }
}
